### Corfiv4

## Zrobione:

- [X] Statystyki I liczniki na kanałach głosowych (Zrobione)
- [X] Shardy (Zrobione)
- [X] Auto Moderacja (Zrobione)
- [X] Weryfikacja (Zrobione) 


## W trakcie:

- [ ] Autokanały (Nie zrobione)
- [ ] Levele (W trakcie)
- [ ] Powiadomienia z YT (W trakcie)

## Do zrobienia:

- [x] Reaction Roles 





<img src="https://cdn.discordapp.com/attachments/851522050078408704/899233611805491200/error.png">
