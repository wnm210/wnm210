const { MessageEmbed } = require("discord.js");
const emotki = require ('../../base/emotki.json')

module.exports = {
    name : 'leaderboard',
    aliases: ['ranks', 'topxp', 'lb'],
    category : 'leveling',
    description : 'Wyświetla TOP 10 poziomów',
    run : async(client, message, args) => {

    }
}
